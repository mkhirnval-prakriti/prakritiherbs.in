const menuBtn = document.querySelector(".mobile-menu-btn");
const sidebar = document.querySelector("#mobileSidebar");
const closeBtn = document.querySelector(".close-sidebar");
const overlay = document.querySelector(".sidebar-overlay");

menuBtn.addEventListener("click", () => {
  sidebar.classList.add("active");
  overlay.classList.add("active");
  document.body.classList.add("scroll-lock");
});

closeBtn.addEventListener("click", () => {
  sidebar.classList.remove("active");
  overlay.classList.remove("active");
  document.body.classList.remove("scroll-lock");
});

overlay.addEventListener("click", () => {
  sidebar.classList.remove("active");
  overlay.classList.remove("active");
  document.body.classList.remove("scroll-lock");
});

const endTime = new Date().getTime() + 24 * 60 * 60 * 1000;

setInterval(() => {
  const now = new Date().getTime();
  const diff = endTime - now;

  const h = Math.floor(diff / (1000 * 60 * 60));
  const m = Math.floor((diff / (1000 * 60)) % 60);
  const s = Math.floor((diff / 1000) % 60);

  document.querySelectorAll(".time")[0].textContent = h
    .toString()
    .padStart(2, "0");
  document.querySelectorAll(".time")[1].textContent = m
    .toString()
    .padStart(2, "0");
  document.querySelectorAll(".time")[2].textContent = s
    .toString()
    .padStart(2, "0");
}, 1000);

const saveBtn = document.getElementById("saveBtn");
saveBtn.addEventListener("click", function () {
  this.classList.add("active");

  setTimeout(() => {
    this.classList.remove("active");
  }, 1400);
});
